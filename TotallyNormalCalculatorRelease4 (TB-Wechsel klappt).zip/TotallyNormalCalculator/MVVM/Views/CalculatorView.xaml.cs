﻿using System.Windows.Controls;

namespace TotallyNormalCalculator.MVVM.Views
{
    public partial class CalculatorView : UserControl
    {
        public CalculatorView()
        {
            InitializeComponent();
        }
    }
}
