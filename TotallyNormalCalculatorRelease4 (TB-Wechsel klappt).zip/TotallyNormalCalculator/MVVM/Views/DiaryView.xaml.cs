﻿using System.Windows.Controls;

namespace TotallyNormalCalculator.MVVM.Views
{
    public partial class DiaryView : UserControl
    {
        public DiaryView()
        {
            InitializeComponent();
        }
    }
}
